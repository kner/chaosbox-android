# EXIF UserComment

Kleine Android-App zum Auswählen einer JPG-Datei, Erfassen von Box, Kategorie und
Kommentar sowie Speichern einer auf maximal 100 kB reduzierten Kopie. Die Daten
werden zusammen mit Erstellungs- und Änderungsdatum als JSON im EXIF-Feld
`UserComment` gespeichert.

Beim ersten Start wird die mitgelieferte Setupdatei nach
`/storage/emulated/0/ChaosBox/Setup/setup.ini` auf das Smartphone kopiert. Die Kategorien werden bei
jedem App-Start aus deren Abschnitt `[Kategorie]` geladen. Dadurch kann die Liste
mit einem Dateimanager oder Texteditor geändert werden.

Die Ausgabe wird unter `/storage/emulated/0/ChaosBox/JPG` abgelegt. Aus `foto.jpg` wird `foto_cb.jpg`.

## Build

```bash
./gradlew assembleDebug
```

Die Debug-APK liegt anschließend unter `app/build/outputs/apk/debug/app-debug.apk`.

Für Android 11+ beim ersten Start den Zugriff auf alle Dateien erlauben. Vorhandene Bilder und Konfigurationen unter Pictures/cbox werden nicht automatisch verschoben. Eine vorhandene ChaosBox/Setup/setup.ini bleibt erhalten. Bei gleichem Bildnamen wird eine nummerierte Kopie gespeichert.
